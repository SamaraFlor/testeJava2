package br.com.linkedRh.javaTeste;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TesteJavaApplicationTests {

	@Test
	void contextLoads() {
	}

}
