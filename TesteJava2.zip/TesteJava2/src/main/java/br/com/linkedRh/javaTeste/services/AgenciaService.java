package br.com.linkedRh.javaTeste.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.linkedRh.javaTeste.Model.Agencia;
import br.com.linkedRh.javaTeste.Repositories.AgenciaRepository;

@Service
public class AgenciaService {

	@Autowired
	AgenciaRepository repository;

	public Agencia findById(Long agenciaId) {
		return repository.findById(agenciaId);
}
}
