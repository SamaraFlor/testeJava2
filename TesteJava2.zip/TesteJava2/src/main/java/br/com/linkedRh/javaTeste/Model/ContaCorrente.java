package br.com.linkedRh.javaTeste.Model;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ContaCorrente {
	private Long id;
	private Long correntistaId;
	private Correntista correntista;
	private Long agenciaId;
	private Agencia agencia;
	private BigDecimal limite = BigDecimal.ZERO;
	private BigDecimal saldo = BigDecimal.ZERO;
	private boolean ativa = true;
	
	public void mostrarCorrentista(Correntista correntista) {
		this.correntista = correntista;
		this.correntistaId = correntista == null ? null : correntista.getId();
	}
	
	public void adicionarSaldo(BigDecimal value) {
		this.saldo = this.saldo.add(value);
	}
	
	public void mudarSaldo(BigDecimal value) {
		this.saldo = this.saldo.subtract(value);
	}
	
	public void mostrarAgencia(Agencia agencia) {
		this.agencia = agencia;
		this.agenciaId = agencia == null ? null : agencia.getId();
	}
	
	public void mostrarSaldo(BigDecimal saldo) throws Exception {
		if (saldo == null) saldo = BigDecimal.ZERO; 
		if (saldo.compareTo(BigDecimal.ZERO) < 0 && !limiteEspecial()) throw new Exception("o seu saldo não tem lis");
		this.saldo = saldo;
	}
	
	public void mostrarLimite(BigDecimal limite) throws Exception {
		if (limite == null) limite = BigDecimal.ZERO; 
		this.limite = limite;
	}
	
	public boolean limiteEspecial() {
		if (limite == null) limite = BigDecimal.ZERO; 
		return limite.compareTo(BigDecimal.ZERO) > 0;
	}
	

}
