package br.com.linkedRh.javaTeste.DTOS;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;



@Data
@AllArgsConstructor
@NoArgsConstructor
public class MovimentacaoDTO {
	
	private Long conta;
	private Long agencia;
	private BigDecimal valor;
	private Long contaTransferencia;
	private Long agenciaTransferencia;
}
	

