package br.com.linkedRh.javaTeste.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.linkedRh.javaTeste.Model.Correntista;
import br.com.linkedRh.javaTeste.Repositories.CorrentistaRepository;

@Service
public class CorrentistaService {

	@Autowired
	CorrentistaRepository repository;
	
	public Correntista findByCpf(String cpf) {
		return repository.consultarDados(cpf);
	}
	
	public Correntista consultarDados(Correntista correntista) throws Exception {		
		if (correntista.getCpf() == null) {
			throw new Exception ("CPF não foi informado");
		}	
		
		var cliente = findByCpf(correntista.getCpf());
		
		if (cliente == null) {
			throw new Exception ("CPF não foi cadastrado");
		}
			
		return cliente;
	}
	
	public Correntista consultarDados(String cpf) {		
		return repository.consultarDados(cpf);
	}
}
