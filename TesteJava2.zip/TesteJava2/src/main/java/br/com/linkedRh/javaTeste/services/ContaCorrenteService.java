package br.com.linkedRh.javaTeste.services;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.linkedRh.javaTeste.DTOS.ContaCorrenteDTO;
import br.com.linkedRh.javaTeste.DTOS.MovimentacaoDTO;
import br.com.linkedRh.javaTeste.Model.Agencia;
import br.com.linkedRh.javaTeste.Model.ContaCorrente;
import br.com.linkedRh.javaTeste.Repositories.ContaCorrenteRepository;

@Service
public class ContaCorrenteService {

	@Autowired
	ContaCorrenteRepository repository;

	@Autowired
	AgenciaService agenciaService;
	
	@Autowired
	CorrentistaService correntistaService;
	
	
	public ContaCorrente novaConta(ContaCorrenteDTO contaCorrente) throws Exception {
		if (contaCorrente.getAgencia() == 0) throw new Exception("Não encontramos esta agencia");
		
		var conta = new ContaCorrente();
		conta.setAgenciaId(Long.parseLong(String.valueOf(contaCorrente.getAgencia())));
		var agencia = agenciaService.findById(conta.getAgenciaId());
		if (agencia == null) {
			throw new Exception("agencia não encontrada");
		}	
		conta.setAgencia(agencia);	
		conta.setCorrentista(contaCorrente.getCorrentista());
		conta.setLimite(contaCorrente.getLimite());
		conta.setSaldo(contaCorrente.getSaldoInicial());
		
		return novaConta(contaCorrente);
	}	
	
	public ContaCorrente novaConta(ContaCorrente contaCorrente) throws Exception {
		if(!(contaCorrente.getSaldo().compareTo(BigDecimal.ZERO) > 0)) {
			throw new Exception("Saldo insuficiente");
		}
		return repository.salvar(contaCorrente);
	}
	
	public ContaCorrente consultarSaldo(ContaCorrente contaCorrente) throws Exception {		
		if (contaCorrente.getAgenciaId() == null) {
			throw new Exception ("Agencia não foi encontrada");
		}	
		
		var agencia = agenciaService.findById(contaCorrente.getAgenciaId());
		
		ContaCorrente conta = findByIdAndAgenciaId(contaCorrente.getCorrentistaId(), agencia.getId());
		
		if (conta == null) {
			throw new Exception ("Conta não foi encontrada");
		}	
		
		return conta;
	}
	
	

	private ContaCorrente CorrentistaIdeAgenciaId(Long correntistaId, Long agenciaId) {
		return repository.findByCorrentistaIdAndAgenciaId(correntistaId, agenciaId);
	}
	
	public ContaCorrente adicionarSaldo(ContaCorrente contaCorrente) throws Exception {
		if (contaCorrente.getAgenciaId() == 0) throw new Exception("Conta não foi encontrada");
		
		Long agenciaId = Long.parseLong(String.valueOf(contaCorrente.getAgenciaId()));
		
		var agencia = agenciaService.findById(agenciaId);
		if (agencia == null) {
			throw new Exception("Conta não foi encontrada");
		}
		
       var conta = consultarSaldo(contaCorrente);
		
		if (conta == null) {
			throw new Exception("Conta não foi encontrada");
		}
		
		conta.adicionarSaldo(contaCorrente.getSaldo());
		
		return consultarSaldo(conta);
	}
	public ContaCorrente novoSaldo(ContaCorrente contaCorrente) throws Exception {
		if (contaCorrente.getSaldo().compareTo(BigDecimal.ZERO) < 0 && !contaCorrente.limiteEspecial()) {
			throw new Exception("Não possui limite lis");
		}
		
		return repository.adicionarSaldo(contaCorrente);
	}
	
	public ContaCorrente removerSaldo(ContaCorrente contaCorrente) throws Exception {
		if (contaCorrente.getAgenciaId() == 0) throw new Exception("Conta não foi encontrada");
		
		Long agenciaId = Long.parseLong(String.valueOf(contaCorrente.getAgenciaId()));
		
		var agencia = agenciaService.findById(agenciaId);
		if (agencia == null) {
			throw new Exception("Conta não foi encontrada");
		}
		
		var conta = consultarSaldo(contaCorrente);
		
		if (conta == null) {
			throw new Exception("Conta não foi encontrada");
		}
		
		if(contaCorrente.getSaldo().compareTo(conta.getSaldo().add(conta.getLimite())) > 0) {
			throw new Exception("Você não tem saldo + '/n' limite suficiente");
		}
		
		conta.mostrarSaldo(contaCorrente.getSaldo());
		
		return novoSaldo(conta);
	}
	  public void desativarConta(ContaCorrente contaCorrente) throws Exception {		
		if (contaCorrente.getAgenciaId() == null) {
			throw new Exception ("Agencia não foi informada");
		}
		
       ContaCorrente conta = CorrentistaIdeAgenciaId(contaCorrente.getCorrentistaId(), contaCorrente.getAgenciaId());
		
		if (conta == null) {
			throw new Exception ("Conta não foi encontrada");
		}	
		
		if (!conta.isAtiva()) {
			throw new Exception ("Conta já esta inativa");
		}
		
		repository.desativarConta(conta);
	}
	  
	  public void movimentar(MovimentacaoDTO movimento) throws Exception {
			if (movimento.getValor().compareTo(BigDecimal.ZERO) < 1) {
				throw new Exception ("Valor inferior");
			}	
			ContaCorrente contaOrigem = findByIdAndAgenciaId(movimento.getContaTransferencia(), movimento.getAgencia());
			if (contaOrigem == null) {
				throw new Exception ("Conta não existe");
			}
			ContaCorrente contaDestino = findByIdAndAgenciaId(movimento.getContaTransferencia(), movimento.getAgenciaTransferencia());
			if (contaDestino == null) {
				throw new Exception ("Conta não existente");
			}
			
			contaOrigem.setSaldo(movimento.getValor());
			removerSaldo(contaOrigem);
			
			contaDestino.setSaldo(movimento.getValor());
			adicionarSaldo(contaDestino);
		}

		private ContaCorrente findByIdAndAgenciaId(Long contaOrigem, Long agenciaOrigem) {
			return repository.findByIdAndAgenciaId(contaOrigem, agenciaOrigem);
		}
		
}
