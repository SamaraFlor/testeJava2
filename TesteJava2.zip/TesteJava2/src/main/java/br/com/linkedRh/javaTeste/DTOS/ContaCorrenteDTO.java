package br.com.linkedRh.javaTeste.DTOS;

import java.math.BigDecimal;

import br.com.linkedRh.javaTeste.Model.Correntista;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class ContaCorrenteDTO {

	private int agencia;
	private Correntista correntista;
	private BigDecimal limite;
	private BigDecimal saldoInicial;
	
}

