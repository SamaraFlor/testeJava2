package br.com.linkedRh.javaTeste.Repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.SingleConnectionDataSource;
import org.springframework.stereotype.Repository;
import br.com.linkedRh.javaTeste.Model.Agencia;

@Repository
public class AgenciaRepository {



@Autowired
JdbcTemplate jdbcTemplate;

@Autowired
SingleConnectionDataSource singleConnection;

private static final String FIND_BY_ID = "SELECT id, nome, endereco FROM agencia WHERE id = ?";

public Agencia findById(Long agenciaId) {
	PreparedStatement statement;
	Agencia agencia = null;
	try {
		statement = singleConnection.getConnection().prepareStatement(FIND_BY_ID);
		statement.setLong(1, agenciaId);
		ResultSet resultado = statement.executeQuery();
		if (resultado.next()){
			agencia = new Agencia();
			agencia.setId(resultado.getLong("id"));
			agencia.setNome(resultado.getString("nome"));
			agencia.setEndereco(resultado.getString("endereco"));
		}			
	} catch (SQLException e) {
		e.printStackTrace();
	}
		
	return agencia;
}


}