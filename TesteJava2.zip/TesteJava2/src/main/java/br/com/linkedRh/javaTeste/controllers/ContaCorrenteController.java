package br.com.linkedRh.javaTeste.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.linkedRh.javaTeste.DTOS.ContaCorrenteDTO;
import br.com.linkedRh.javaTeste.DTOS.MovimentacaoDTO;
import br.com.linkedRh.javaTeste.Model.ContaCorrente;
import br.com.linkedRh.javaTeste.Model.Correntista;
import br.com.linkedRh.javaTeste.services.ContaCorrenteService;
import br.com.linkedRh.javaTeste.services.CorrentistaService;

@RestController
@RequestMapping("Conta")
public class ContaCorrenteController {

	 @Autowired
	 ContaCorrenteService contaCorrenteService;
	 
	 @Autowired
	 CorrentistaService correntistaService;

	 
	 @PostMapping
	 public ResponseEntity<?> contaCorrente(@RequestBody ContaCorrenteDTO contaCorrente) {		 
		try {
			return new ResponseEntity<>(contaCorrenteService.novaConta(contaCorrente), HttpStatus.CREATED);
		} catch (Exception e) {
			if (e.getMessage().equals("Agencia não encontrada")) return new ResponseEntity<>(e, HttpStatus.NOT_FOUND);	
			return new ResponseEntity<>	(e.getMessage(), HttpStatus.BAD_REQUEST);
		}
	 }  

	 @GetMapping("consultar")
	 public ResponseEntity<?> contaCorrente(@RequestBody ContaCorrente contaCorrente) {		 
		try {
			return new ResponseEntity<>(contaCorrenteService.consultarSaldo(contaCorrente), HttpStatus.OK);
		} catch (Exception e) {
			if (e.getMessage().equals("A sua conta não foi encontrada")) return new ResponseEntity<>(e, HttpStatus.NOT_FOUND);	
			return new ResponseEntity<>	(e.getMessage(), HttpStatus.BAD_REQUEST);
		}
	 } 
	 
	 @PatchMapping("depositar")
	 public ResponseEntity<?> adicionarSaldo(@RequestBody ContaCorrente contaCorrente) {		 
		try {
			return new ResponseEntity<>(contaCorrenteService.adicionarSaldo(contaCorrente), HttpStatus.OK);
		} catch (Exception e) {
			switch (e.getMessage()) {
			case "Saldo insufiente ":
				return new ResponseEntity<>(e.getMessage(), HttpStatus.FORBIDDEN);		
			case " A sua conta não foi encontrada":			
				return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
			default:
				return new ResponseEntity<>	(e.getMessage(), HttpStatus.BAD_REQUEST);
			}				
		}
	 }  
	 
	 @PatchMapping("saque")
	 public ResponseEntity<?> verificarSaldo(@RequestBody ContaCorrente contaCorrente) {		 
		try {
			return new ResponseEntity<>(contaCorrenteService.consultarSaldo(contaCorrente), HttpStatus.OK);
		} catch (Exception e) {
			switch (e.getMessage()) {
			case "Você não tem saldo suficiente + limite suficiente":
				return new ResponseEntity<>(e.getMessage(), HttpStatus.FORBIDDEN);		
			case "Conta não foi encontrada":			
				return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
			default:
				return new ResponseEntity<>	(e.getMessage(), HttpStatus.BAD_REQUEST);
			}				
		}
	 }  
	 
	 @DeleteMapping("desativar")
	 public ResponseEntity<?> desativarConta(@RequestBody ContaCorrente contaCorrente) {		 
		try {
			contaCorrenteService.desativarConta(contaCorrente);
			return new ResponseEntity<>(HttpStatus.OK);
		} catch (Exception e) {
			switch (e.getMessage()) {
			case "Conta não encontrada":
				return new ResponseEntity<>(e.getMessage(), HttpStatus.FORBIDDEN);		
			case "Conta esta inativa":			
				return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_MODIFIED);
			default:
				return new ResponseEntity<>	(e.getMessage(), HttpStatus.BAD_REQUEST);
			}				
		}
	 }
	 
	 @GetMapping("cliente")
	 public ResponseEntity<?> correntista(@RequestBody Correntista correntista) {		 
		try {
			return new ResponseEntity<>(correntistaService.consultarDados(correntista), HttpStatus.OK);
		} catch (Exception e) {
			if (e.getMessage().equals("Conta não encontrada")) return new ResponseEntity<>(e, HttpStatus.NOT_FOUND);	
			return new ResponseEntity<>	(e.getMessage(), HttpStatus.BAD_REQUEST);
		}
	 } 
	 
	 @PatchMapping("transferencia")
	 public ResponseEntity<?> transferencia(@RequestBody MovimentacaoDTO movimentacao) {		 
		try {
			contaCorrenteService.movimentar(movimentacao);
			return new ResponseEntity<>(HttpStatus.OK);
		} catch (Exception e) {
			switch (e.getMessage()) {
			case "Saldo insufiente":
				return new ResponseEntity<>(e.getMessage(), HttpStatus.FORBIDDEN);		
			case "Conta não existe":			
				return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
			default:
				return new ResponseEntity<>	(e.getMessage(), HttpStatus.BAD_REQUEST);
			}	
		}
       
	 }
}
	 

	
